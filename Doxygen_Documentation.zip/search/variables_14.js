var searchData=
[
  ['validate_1075',['validate',['../src_2js_2brutusin-json-forms_8js.html#ad731355cdc73d5e401b719758100cc2a',1,'brutusin-json-forms.js']]],
  ['version_1076',['VERSION',['../bootstrap_8min_8js.html#a3635f2df5844f69204b70bf7b3983587',1,'bootstrap.min.js']]]
];
