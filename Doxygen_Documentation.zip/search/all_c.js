var searchData=
[
  ['k_246',['k',['../prettify_8js.html#a4f7bf59aee925e80b9e8163664741bb6',1,'k(O,[&quot;default-code&quot;]):&#160;prettify.js'],['../prettify_8js.html#ac0f5b018c200154a83b6e6126ba14d91',1,'k(x([[&quot;pln&quot;,/^\s+/, q,&quot; \t\r\n&quot;],[&quot;atv&quot;,/^(?:&quot;[^&quot;] *&quot;?|&apos;[^&apos;]*&apos;?)/,q,&quot;\&quot;&apos;&quot;]],[[&quot;tag&quot;,/^^&lt;\/?[a-z](?:[\w-.:] *\w)?|\/?&gt;$/i],[&quot;atn&quot;,/^(?!style[\s=]|on)[a-z](?:[\w:-] *\w)?/i],[&quot;lang-uq.val&quot;,/^=\s *([^\s&quot;&apos;&gt;]*(?:[^\s&quot;&apos;/&gt;]|\/(?=\s)))/],[&quot;pun&quot;,/^[/&lt;-&gt;]+/],[&quot;lang-js&quot;,/^on\w+\s *=\s *&quot;([^&quot;]+)&quot;/i],[&quot;lang-js&quot;,/^on\w+\s*=\s*&apos;([^&apos;]+)&apos;/i],[&quot;lang-js&quot;,/^on\w+\s*=\s*([^\s&quot;&apos;&gt;]+)/i]:&#160;prettify.js']]],
  ['keymap_247',['keyMap',['../codemirror_8js.html#a3db02b4c78699674d1496bdcd90138c5',1,'codemirror.js']]],
  ['keyname_248',['keyName',['../codemirror_8js.html#a80b8c56a535490df5d538afeba3960ad',1,'codemirror.js']]]
];
