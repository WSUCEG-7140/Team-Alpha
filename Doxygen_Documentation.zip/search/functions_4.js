var searchData=
[
  ['date_5fvalidation_5fon_5fsuccess_647',['date_validation_on_success',['../namespacetest__main.html#aecf458dcbbd66d3a19add832333996ab',1,'test_main']]],
  ['defaultspecialcharplaceholder_648',['defaultSpecialCharPlaceholder',['../codemirror_8js.html#a113b33e5d87b3cb38fdaeeab3a65929e',1,'codemirror.js']]],
  ['definemime_649',['defineMIME',['../codemirror-javascript_8js.html#a64d33d2000bc99d4c63293b6b73da1a3',1,'defineMIME(&quot;text/javascript&quot;, &quot;javascript&quot;):&#160;codemirror-javascript.js'],['../codemirror_8js.html#a57679c816d382a5fc741b332cc499c03',1,'defineMIME(&quot;text/plain&quot;, &quot;null&quot;):&#160;codemirror.js']]],
  ['definemode_650',['defineMode',['../codemirror-javascript_8js.html#a1f6f653484c2e2facf0d187345fef3cd',1,'defineMode(&quot;javascript&quot;, function(config, parserConfig) { var indentUnit=config.indentUnit;var statementIndent=parserConfig.statementIndent;var jsonldMode=parserConfig.jsonld;var jsonMode=parserConfig.json||jsonldMode;var isTS=parserConfig.typescript;var wordRE=parserConfig.wordCharacters||/[\w$\xa1-\uffff]/;var keywords=function(){ function kw(type) {return {type:type, style:&quot;keyword&quot;};} var A=kw(&quot;keyword a&quot;), B=kw(&quot;keyword b&quot;), C=kw(&quot;keyword c&quot;);var operator=kw(&quot;operator&quot;), atom={type:&quot;atom&quot;, style:&quot;atom&quot;};var jsKeywords={ &quot;if&quot;:kw(&quot;if&quot;), &quot;while&quot;:A, &quot;with&quot;:A, &quot;else&quot;:B, &quot;do&quot;:B, &quot;try&quot;:B, &quot;finally&quot;:B, &quot;return&quot;:C, &quot;break&quot;:C, &quot;continue&quot;:C, &quot;new&quot;:C, &quot;delete&quot;:C, &quot;throw&quot;:C, &quot;debugger&quot;:C, &quot;var&quot;:kw(&quot;var&quot;), &quot;const&quot;:kw(&quot;var&quot;), &quot;let&quot;:kw(&quot;var&quot;), &quot;async&quot;:kw(&quot;async&quot;), &quot;function&quot;:kw(&quot;function&quot;), &quot;catch&quot;:kw(&quot;catch&quot;), &quot;for&quot;:kw(&quot;for&quot;), &quot;switch&quot;:kw(&quot;switch&quot;), &quot;case&quot;:kw(&quot;case&quot;), &quot;default&quot;:kw(&quot;default&quot;), &quot;in&quot;:operator,&quot;typeof&quot;:operator,&quot;instanceof&quot;:operator,&quot;true&quot;:atom, &quot;false&quot;:atom, &quot;null&quot;:atom, &quot;undefined&quot;:atom, &quot;NaN&quot;:atom, &quot;Infinity&quot;:atom, &quot;this&quot;:kw(&quot;this&quot;), &quot;class&quot;:kw(&quot;class&quot;), &quot;super&quot;:kw(&quot;atom&quot;), &quot;await&quot;:C, &quot;yield&quot;:C, &quot;export&quot;:kw(&quot;export&quot;), &quot;import&quot;:kw(&quot;import&quot;), &quot;extends&quot;:C };if(isTS) { var type={type:&quot;variable&quot;, style:&quot;variable-3&quot;};var tsKeywords={ &quot;interface&quot;:kw(&quot;interface&quot;), &quot;extends&quot;:kw(&quot;extends&quot;), &quot;constructor&quot;:kw(&quot;constructor&quot;), &quot;public&quot;:kw(&quot;public&quot;), &quot;private&quot;:kw(&quot;private&quot;), &quot;protected&quot;:kw(&quot;protected&quot;), &quot;static&quot;:kw(&quot;static&quot;), &quot;string&quot;:type, &quot;number&quot;:type, &quot;bool&quot;:type, &quot;any&quot;:type };for(var attr in tsKeywords) { jsKeywords[attr]=tsKeywords[attr];} } return jsKeywords;}();var isOperatorChar=/[+\- *&amp;%=&lt;&gt;!?|~^]/;var isJsonldKeyword=/^@(context|id|value|language|type|container|list|set|reverse|index|base|vocab|graph)&quot;/;

  function readRegexp(stream) {
    var escaped = false, next, inSet = false;
    while ((next = stream.next()) != null) {
      if (!escaped) {
        if (next == &quot;/&quot; &amp;&amp; !inSet) return;
        if (next == &quot;[&quot;) inSet = true;
        else if (inSet &amp;&amp; next == &quot;]&quot;) inSet = false;
      }
      escaped = !escaped &amp;&amp; next == &quot;\\&quot;;
    }
  }

  // Used as scratch variables to communicate multiple values without
  // consing up tons of objects.
  var type, content;
  function ret(tp, style, cont) {
    type = tp; content = cont;
    return style;
  }
  function tokenBase(stream, state) {
    var ch = stream.next();
    if (ch == &apos;&quot;&apos;||ch==&quot;&apos;&quot;):&#160;codemirror-javascript.js'],['../codemirror_8js.html#aaaa61854bee66b5d03dbde92e4bb5ec2',1,'defineMode(&quot;null&quot;, function() { return {token:function(stream) {stream.skipToEnd();}};}):&#160;codemirror.js']]],
  ['delayblurevent_651',['delayBlurEvent',['../codemirror_8js.html#a689d87b8512ba0f4ee56e76157856722',1,'codemirror.js']]],
  ['deletenearselection_652',['deleteNearSelection',['../codemirror_8js.html#a128e9cb80a99546da1a34dc5b88a7934',1,'codemirror.js']]],
  ['detachmarkedspans_653',['detachMarkedSpans',['../codemirror_8js.html#a6dacb8cccafc6730cffd65587299ea8f',1,'codemirror.js']]],
  ['detachsharedmarkers_654',['detachSharedMarkers',['../codemirror_8js.html#abb989307cf86c81225552d5fbadb840c',1,'codemirror.js']]],
  ['disablebrowsermagic_655',['disableBrowserMagic',['../codemirror_8js.html#a00c8c09e00b3f210eab478109b9f1a2c',1,'codemirror.js']]],
  ['dispatchkey_656',['dispatchKey',['../codemirror_8js.html#ad17fa486067b387ebed8f22c2b6edb72',1,'codemirror.js']]],
  ['display_657',['Display',['../codemirror_8js.html#abcfbba4abacd178c4b78af92562751b3',1,'codemirror.js']]],
  ['displayheight_658',['displayHeight',['../codemirror_8js.html#a31e7029a14ef73b972228583d11a4785',1,'codemirror.js']]],
  ['displayupdate_659',['DisplayUpdate',['../codemirror_8js.html#a3a73b297a2b4fde1d7b5c8a9d57d47b1',1,'codemirror.js']]],
  ['displaywidth_660',['displayWidth',['../codemirror_8js.html#ad0c23c3fddc4c2df878e42f492658d0c',1,'codemirror.js']]],
  ['docmethodop_661',['docMethodOp',['../codemirror_8js.html#a286c385988007cabf593674a4cdfc3b8',1,'codemirror.js']]],
  ['dohandlebinding_662',['doHandleBinding',['../codemirror_8js.html#a64f7d469a352a595807a619f5c09cdfd',1,'codemirror.js']]],
  ['domtextbetween_663',['domTextBetween',['../codemirror_8js.html#a1f360212ac87fd16d695812fe4706399',1,'codemirror.js']]],
  ['domtopos_664',['domToPos',['../codemirror_8js.html#a4dd5fc00d7f7429c8e6f1e67d5218fe5',1,'codemirror.js']]],
  ['dragdropchanged_665',['dragDropChanged',['../codemirror_8js.html#a452f533f8e1de09e007f36b138ded219',1,'codemirror.js']]],
  ['drawselectioncursor_666',['drawSelectionCursor',['../codemirror_8js.html#af54415aea0eaec05a95ba08ce45687de',1,'codemirror.js']]],
  ['drawselectionrange_667',['drawSelectionRange',['../codemirror_8js.html#a37afb03b626351bf23a8d9d752e8dcf6',1,'codemirror.js']]]
];
